# ios-builds-dev-client

A dev client that starts its own Metro. Open the app on the phone, and it asks
ios-builds to run `expo start` for this project on the Mac mini, waits until
Metro answers at the project's fixed address on the ios-builds tunnel (for
example `unpeat-8202.botnut.net`), then loads it. That takes about 5 s. There
is no QR code to scan.

While it waits, the launcher's home screen shows an **ios-builds** card, so
you can see what happens:

- each step: the Mac agent, Metro (with the time it has taken), the tunnel,
  and loading the app, with the error of any step that failed
- the Metro log for this app, as the agent sends it (the **Log** button)
- every Metro that runs on the Mac, with its port and state
- **Start Metro** or **Open app**, **Restart** and **Stop** for this app's Metro

Under the Metro list, the **Your dev apps** section is an app switcher. It
shows the other dev apps that ios-builds knows (the `apps` field of
`/status`), with the apps that have a running Metro first. Each row shows the
app icon, the name and the Metro state. Tap a row to open that app. Its own
launcher then wakes its Metro. If the server does not send `apps`, the card
does not show the section.

To see the card again after the app loads, open the dev menu and go home.

This is not a full fork of expo-dev-client. It is one patch-package patch on
`expo-dev-launcher` plus a config plugin, kept here so that every app shares
them. An SDK upgrade only needs the patch made again.

The package is TypeScript in `src/`. `app.plugin.js` is the only JS file,
because Expo looks for that name. It loads `build/plugin.js`, which `sync`
builds with `bun build`.

## How it works

1. The config plugin (`src/plugin.ts`) writes `IOSBuildsWakeURL`, `IOSBuildsWakeToken` and
   `IOSBuildsSlug` into Info.plist. The URL and token come from
   `~/.config/ios-builds/wake.json` on the Mac, not from the repo.
2. `ios-builds-patch` (`src/patch.ts`) runs patch-package with `patches/`.
   The patch adds `ios/SwiftUI/IOSBuilds.swift` to `expo-dev-launcher` and
   hooks it in at two places. In `EXDevLauncherController.m`, when the
   Info.plist has a wake URL and the app did not open from a deep link, the
   launcher shows its home screen and `IOSBuildsMonitor` posts the bundle id
   and slug to the wake URL every two seconds, for up to ten minutes. In
   `HomeTabView.swift`, it adds the card, which polls Convex `/status` every
   two seconds while it is on screen and sends Restart and Stop to `/metro`.
3. Convex `/wake` (convex/http.ts) finds the project by the bundle id of a
   build it has seen, or by slug. It queues a `startMetro` command and answers
   `starting` until the agent reports a tunnel URL, then answers with the URL.
4. The launcher loads that URL. If you open a server by hand first, the polling
   stops.

The agent sends Metro's output to Convex (`metroLogs`, the newest 60 chunks
for each project), and a new start clears it. The MCP tool `get_metro_log`
reads the same log.

## When something goes wrong

- A Metro that does not answer through its address in 60 s, or exits before
  it is ready, is started again once. The second failure marks it failed.
  Metro runs with `EXPO_OFFLINE=1`, because Expo's network checks before the
  bundler starts made some starts hang.
- Every minute the agent checks cloudflared's `/ready` and starts it again if
  it has lost Cloudflare, and starts a Metro again after three failed
  `/status` checks on its own port. A slow answer through the tunnel alone
  does nothing, because Metro is often busy building a bundle.
- When Metro is ready, the agent asks it for the iOS bundle itself, so the
  phone gets a bundle that is already built.
- A dev client that fails to load the app 3 times in a row asks for a restart.
- A build that fails because code signing lost its certificate (another
  process reset the keychain search list) is built again once.
- Problems go to Sentry, project `lucas-knight/ios-builds`. The agent reports
  failed and retried Metro starts, dead tunnels and failed builds. The dev
  client posts what it sees to Convex `/report` (gave up, load failed, Metro
  failed, agent offline, refused), once per kind for each wake, and Convex
  sends it to Sentry with this app's Metro state and the end of its log. Read
  them with `sentry issue list lucas-knight/ios-builds`.

The agent runs Metro on the project's own port (`metroPort` in Convex) and
stops it after 30 minutes with no connection (`METRO_IDLE_MINUTES`).

The plugin omits wake configuration for the `testflight`, `production`, and
`adhoc` EAS profiles. The launcher hook is active in Debug dev clients.
`testflight-dev` uses store distribution with Debug configuration and the
app's dev variant (`APP_VARIANT`), so it has the `.dev` bundle ID and its own
App Store Connect record. Never give it the production bundle ID or the
`testflight` `ascAppId`: TestFlight then puts the dev client in the release
app, and it replaces the release install on the phone.

## Add it to an app

```sh
bun /Users/ljk/p/labs/ios-builds/packages/dev-client/src/sync.ts <app-directory>
cd <app-directory> && bun add expo-dev-client
```

`sync.ts` builds and packs this package into
`<app>/vendor/ios-builds-dev-client-<hash>.tgz`, points the dependency at it
and runs `bun install --force`. Commit the tarball. A `file:` path to this
folder does not work: Bun writes it into bun.lock relative to the app, and it
does not resolve in the temp copy that `eas build --local` makes. The hash in
the name is necessary. With a fixed name, Bun keeps the old integrity hash in
bun.lock after the tarball changes, and the next EAS build fails with
`IntegrityCheckFailed`. `--force` extracts the patched packages again, so the
new patch applies to clean copies.

The app needs no tunnel package. The agent's named Cloudflare tunnel serves
every project (see `agent/tunnel.ts`).

Then, in the app's `package.json`:

```json
"scripts": { "postinstall": "ios-builds-patch" }
```

In a monorepo, the workspace root's postinstall must call it through the app,
for example `bun run --cwd apps/app ios-builds:patch`, so the binary resolves.
Keep any postinstall work that is already there. Last, add
`"ios-builds-dev-client"` to the app config plugins.

After a change to this package, run `bun run sync` here with no argument. It
refreshes every app under `~/p` that has a tarball, then rebuild their dev
clients. A change to the patch is native code, so a JS reload is not enough.

The wake token must match `WAKE_TOKEN` in Convex prod, and every dev client
already built carries it. To rotate it, set both, then rebuild every dev
client.

## After an Expo SDK upgrade

`bun install` prints a patch-package error if the patch no longer applies.
Make it again against the new version:

1. Copy `node_modules/expo-dev-launcher` of an upgraded app to a scratch folder
   twice, as `a/node_modules/expo-dev-launcher` and `b/node_modules/...`.
2. Apply the two hooks from the old patch to `b` by hand, and copy
   `ios/SwiftUI/IOSBuilds.swift` into `b`.
3. `git diff --no-index --src-prefix= --dst-prefix= a/node_modules/expo-dev-launcher b/node_modules/expo-dev-launcher > patches/expo-dev-launcher+<version>.patch`
4. In the patch, the header of the new Swift file starts `diff --git b/`.
   Change it to `diff --git a/`, or patch-package cannot parse the file.
5. Type-check the Swift file before a full build:
   `xcrun --sdk iphoneos swiftc -typecheck -target arm64-apple-ios16.4 <stubs> IOSBuilds.swift`,
   with stubs for `EXDevLauncherController` and `Color.expoSecondarySystemGroupedBackground`.
6. Delete the old patch file, then run `bun run sync` to refresh every app.
