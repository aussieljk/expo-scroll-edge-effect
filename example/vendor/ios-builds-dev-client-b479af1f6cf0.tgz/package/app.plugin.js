module.exports = require("./build/plugin.js").default;
